package java002_statements;

//if(조건식){
//if(조건식){
//  수행문장;
//}else{
//  수행문장;
//}
//}else{
//if(조건식){
//   수행문장;
//}else{
//    수행문장;
//}
//}


public class Java017_if {

	public static void main(String[] args) {
		int num = 8;
		
		if(num > 0) {
			System.out.printf("%d는(은) 자연수입니다.\n", num);
		}
		System.out.println("program end");

	}

}
